package input

type InputAdapter interface {
	Process(interface{})
}
